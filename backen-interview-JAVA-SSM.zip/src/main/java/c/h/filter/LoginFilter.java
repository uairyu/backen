package c.h.filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Map;

@WebFilter("/*")
public class LoginFilter implements Filter {
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) servletRequest;
		System.out.println("URI:-" + req.getRequestURI() + "-queryString-"+req.getQueryString()+'-');
		Map<String,String> parameterValues = req.getParameterMap();
		for (String s : parameterValues.keySet()) {
			System.out.println(req.getRequestURI()+ '-' + s+ '-' + req.getParameter(s));
		}
		HttpServletResponse res = (HttpServletResponse) servletResponse;
		res.setHeader("Access-Control-Allow-Origin", req.getHeader("origin"));
//		res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
		res.setHeader("Access-Control-Allow-Credentials", "true");
		res.setHeader("Access-Control-Allow-Headers", "Content-Type, ");
		filterChain.doFilter(servletRequest, servletResponse);
	}

	@Override
	public void destroy() {

	}
}
