package c.h.controller;

import c.h.domain.Artical;
import c.h.service.ArticalService;
import com.github.pagehelper.PageHelper;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@CrossOrigin
public class ArticalController {
    @Autowired
    private ArticalService articalService;

    @RequestMapping("/getShortArtical")
    @ResponseBody
    public List<Artical> getShortArtical(int curPage, Integer pageSize) {
        if (curPage < 0 || curPage > 3) return null;
        if (pageSize != null)
            PageHelper.startPage(curPage, pageSize);
        else
            PageHelper.startPage(curPage, 2);
        return articalService.showShortArtical();
    }
    @RequestMapping("/getShortArtical/{id}")
    @ResponseBody
    public Artical getArtical(@PathVariable("id") int id) {
        Artical a =  articalService.getArtical(id);
        if(a != null){
            return a;
        }
        else{
            return null;
        }
    }
}
