package c.h.controller;

import c.h.domain.User;
import c.h.service.impl.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.net.HttpCookie;
import java.util.Map;
import java.util.Set;

@Controller
//@RequestMapping("/api")
@CrossOrigin
public class APIController {
    @Autowired
    private UserServiceImpl userService;

    @RequestMapping(value = "/register")
    @ResponseBody
    public String register(@RequestBody User user1, HttpSession session) {
        System.out.println("register " + user1);
        if (user1.getUser() != null) {
            boolean b = userService.registerUser(user1);
            if (b) {
                session.setAttribute("user", user1);
                return "success";
            } else {
                return "exist";
            }
        }
        return "fail";
    }

    @RequestMapping(value = "/login")
    @ResponseBody
    public String login(@RequestBody User user1, HttpSession session) {
        System.out.println("sessionID " + session.getId());
        System.out.println("login " + user1);
        if (user1.getUser() != null && user1.getPassword() != null) {
            boolean b = userService.loginUser(user1);
            if (b) {
                System.out.println("login session" + user1);
                session.setAttribute("user", user1);
                return "success";
            } else {
                return "exist";
            }
        }
        return "fail";
    }

    @RequestMapping(value = "/update_user_name")
    @ResponseBody
    public String updateUserName(@RequestBody Map<String, String> user, HttpSession session) {
        System.out.println("sessionID " + session.getId());
        System.out.println("updateUserName " + user);
        for (String s : user.keySet()) {
            System.out.println(s + '-' + user.get(s));
        }
        String newName = user.get("user");
        System.out.println("newName " + newName);
        User user1 = (User) session.getAttribute("user");
        System.out.println("session from " + user1);
        if (user1 != null) {
            boolean b = userService.updateUserName(newName, user1);
            if (b) {
                user1.setUser(newName);
                return "success";
            }
        }
        return "fail";
    }

    @RequestMapping(value = "/logout")
    @ResponseBody
    public String logout(HttpServletRequest req, HttpServletResponse resp, HttpSession session) {
		User user = (User) session.getAttribute("user");
		System.out.println("logout " + user);
		session.invalidate();
        return "success";
    }

    @RequestMapping(value = "/ttt")
    @ResponseBody
    public String fff(HttpSession session) {
        System.out.println("sessionID " + session.getId());
        User user1 = (User) session.getAttribute("user");
        System.out.println("ttt " + user1);
        return "fail";
    }
}
