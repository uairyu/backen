package c.h.service;

import c.h.domain.User;

public interface UserService {
    boolean registerUser(User user);

    boolean existUser(User user);

    boolean loginUser(User user);

    boolean updateUserName(String user, User user1);
}
