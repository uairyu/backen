package c.h.service;

import c.h.domain.Artical;

import java.util.List;

public interface ArticalService {
    List<Artical> showShortArtical();
    Artical getArtical(int id);
}
