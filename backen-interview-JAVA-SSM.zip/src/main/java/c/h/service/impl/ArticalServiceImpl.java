package c.h.service.impl;

import c.h.dao.ArticalDao;
import c.h.domain.Artical;
import c.h.service.ArticalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ArticalServiceImpl implements ArticalService {

    @Autowired
    private ArticalDao articalDao;
    @Override
    public List<Artical> showShortArtical() {
        return articalDao.showShortArtical();
    }

    @Override
    public Artical getArtical(int id) {
        return articalDao.getArtical(id);
    }
}
