package c.h.service.impl;

import c.h.dao.UserDao;
import c.h.dao.mapper.UserMapper;
import c.h.domain.User;
import c.h.service.UserService;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserDao userDao;

    @Override
    public boolean registerUser(User user) {
        if (userDao.existUser(user) == 0) {
            userDao.insertUser(user);
            return true;
        }
        return false;
    }

    @Override
    public boolean existUser(User user) {
        if (userDao.existUser(user) >= 1) {
            return true;
        }
        return false;
    }

    @Override
    public boolean loginUser(User user) {
        if (userDao.loginUser(user)) {
            return true;
        }
        return false;
    }

    @Override
    public boolean updateUserName(String user, User user1) {
        if(userDao.updateUserName(user,user1)){
            return true;
        }
        return false;
    }
}
