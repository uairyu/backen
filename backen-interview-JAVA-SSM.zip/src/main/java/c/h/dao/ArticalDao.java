package c.h.dao;

import c.h.domain.Artical;

import java.util.List;

public interface ArticalDao {
    List<Artical> showShortArtical();

    Artical getArtical(int id);
}
