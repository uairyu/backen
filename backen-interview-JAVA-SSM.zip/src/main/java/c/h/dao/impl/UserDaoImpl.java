package c.h.dao.impl;

import c.h.dao.UserDao;
import c.h.dao.mapper.UserMapper;
import c.h.domain.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserDaoImpl implements UserDao {
    @Autowired
    private UserMapper userMapper;

    @Override
    public int existUser(User user) {
        int i = userMapper.existUser(user.getUser());
        return i;
    }

    @Override
    public void insertUser(User user) {
        userMapper.insertUser(user);
    }

    @Override
    public boolean loginUser(User user) {
        return userMapper.loginUser(user) == 1;
    }

    @Override
    public boolean updateUserName(String user, User user1) {
        try {
            userMapper.updateUserName(user, user1);
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }
}
