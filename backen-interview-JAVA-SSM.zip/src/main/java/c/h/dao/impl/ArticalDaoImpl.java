package c.h.dao.impl;

import c.h.dao.ArticalDao;
import c.h.dao.mapper.ArticalMapper;
import c.h.domain.Artical;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ArticalDaoImpl implements ArticalDao {
    @Autowired
    private ArticalMapper articalMapper;
    @Override
    public List<Artical> showShortArtical() {
        return articalMapper.showArticalIgnoreContent();
    }

    @Override
    public Artical getArtical(int id) {
        return articalMapper.getArtical(id);
    }
}
