package c.h.dao;

import c.h.domain.User;

public interface UserDao {
    int existUser(User user);
    void insertUser(User user);
    boolean loginUser(User user);

    boolean updateUserName(String user, User user1);
}
