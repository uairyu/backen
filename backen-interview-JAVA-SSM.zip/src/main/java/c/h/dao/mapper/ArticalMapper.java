package c.h.dao.mapper;

import c.h.domain.Artical;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ArticalMapper {
    @Select("select id,title,author,date,discusses,views from artical")
    List<Artical> showArticalIgnoreContent();

    @Select("select * from artical where id = ${id}")
    Artical getArtical(@Param("id")Integer id);
}

