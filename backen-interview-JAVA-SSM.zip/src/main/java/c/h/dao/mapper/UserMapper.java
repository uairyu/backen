package c.h.dao.mapper;

import c.h.domain.User;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserMapper {
    @Select("select count(id) from user1 u where u.user = #{user}")
    int existUser(@Param("user") String a);
    @Select("insert into user1(id,user,password) values(null," +
            "#{user.user},#{user.password})")
    void insertUser(@Param("user") User user);

    @Select("select count(id) from user1 u where u.user = #{user.user} and u.password = #{user.password}")
    int loginUser(@Param("user") User user);

    @Select("update user1 u set u.user = #{user} where u.user = #{user1.user}")
    void updateUserName(@Param("user") String user,@Param("user1") User user1);
}

