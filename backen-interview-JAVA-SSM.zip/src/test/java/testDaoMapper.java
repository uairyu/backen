import c.h.dao.mapper.ArticalMapper;
import c.h.dao.mapper.UserMapper;
import c.h.domain.Artical;
import c.h.domain.User;
import com.github.pagehelper.PageHelper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext.xml")
public class testDaoMapper {
    @Autowired
    private UserMapper mapper;
    @Autowired
    private ArticalMapper articalMapper;

    @Test
    public void test2(){
        int i = mapper.existUser("qqq");
        System.out.println(i);
    }
    @Test
    public void test3(){
        User u = new User();
        u.setPassword("paaaa");
        u.setUser("vvvv");
        mapper.insertUser(u);
    }
    @Test
    public void articaltest1() throws IOException {
        PageHelper.startPage(1,2);
        List<Artical> allUser = articalMapper.showArticalIgnoreContent();
//        PageHelper.
        for (Artical artical : allUser) {
            System.out.println(artical);
        }
        System.out.println(allUser);
//
    }
    @Test
    public void articaltest2(){
        Artical artical = articalMapper.getArtical(1);
        System.out.println(artical);
    }
}
