
const env = process.env.NODE_ENV
const myConfig = require('./src/config/_GConfig')
module.exports = {
    publicPath: env==='production'? myConfig.virtualPath : '/'
}