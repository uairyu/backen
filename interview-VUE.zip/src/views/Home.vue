<template>
  <div>
    <main_home></main_home>
  </div>
</template>

<script>
import main_home from './main-home'
export default {
  name: "Home",
  components:{
    main_home
  }
}
</script>

<style scoped>

</style>