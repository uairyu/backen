<template>
    <div class="register-container flex">
        <div class="flex login-panel">
            <div class='flex info-panel'>
                <div style="margin: 0 auto">
                    <el-row>
                        <el-input v-model="user" placeholder="账号"></el-input>
                        <span v-show="usernameTips" style="color: red">请输入符合格式的账号</span>
                    </el-row>
                    <el-row>
                        <el-input placeholder="密码" v-model="password" show-password></el-input>
                        <span v-show="passwordTips" style="color: red">请输入符合格式的密码</span>
                    </el-row>
                    <div class="login-button">
                        <el-row>
                            <el-button @click="register">注册</el-button>
                            <el-button type="success" @click="login">登陆</el-button>
                        </el-row>
                    </div>
                </div>
            </div>
        </div>

    </div>
</template>

<script>
    import {Loading} from 'element-ui';
    import {eB} from "../assets/js/eventBus";

    export default {
        name: "register",
        created() {

        },
        data() {
            return {
                user: '',
                usernameTips: false,
                passwordTips: false,
                password: '',
            }
        },
        components: {},
        watch: {
            user: {
                handler(n, o) {
                    if (n === '' || !this.formCheck(n)) {
                        this.usernameTips = true;
                    } else
                        this.usernameTips = false;
                },
                immediate: false
            },
            password: {
                handler(n) {
                    if (n === '' || !this.formCheck(n)) {
                        this.passwordTips = true;
                        return
                    }
                    this.passwordTips = false;
                },
                immediate: false
            },
        },
        methods: {
            formCheck(s) {
                let b = /^[\w]+$/;
                return b.test(s);
            },
            async login() {
                let axios = this.$axios
                if (!this.formCheck(this.user) || !this.formCheck(this.password)) {
                    return
                }
                let loading = Loading.service()
                let dd = {
                    user: this.user,
                    password: this.password,
                }
                await axios({
                    url: this._G.baseURL + '/login',
                    data: dd,
                    method: 'post',
                    withCredentials: true,
                }).then(res => {
                    if (res.data === "success") {
                        localStorage.setItem('userInfo', JSON.stringify({
                            name: this.user,
                        }))
                        eB.$emit('user-login')
                        this.$notify({
                            title: '登陆成功',
                            message: '3秒后自动为你重定向',
                            type: 'success'
                        });
                        setTimeout(() => {
                            this.$nextTick(() => {
                                let t = this.$route.query.redirect
                                if (t) {
                                    this.$router.push(t)
                                } else {
                                    this.$router.push('/')
                                }
                            })
                        }, 2000)
                    } else if (res.data === 'exist') {
                        this.$notify.error({
                            title: '登陆失败',
                            message: '账号或者密码不正确!'
                        });
                    }
                }).catch(res => {
                    this.$notify.error({
                        title: '登陆失败',
                        message: '服务器繁忙中...'
                    });
                })
                loading.close()
            },
            async register() {
                let axios = this.$axios
                if (!this.formCheck(this.user) || !this.formCheck(this.password)) {
                    return
                }
                let loading = Loading.service()
                let dd = {
                    user: this.user,
                    password: this.password,
                }
                await axios({
                    url: this._G.baseURL + '/register',
                    data: dd,
                    method: 'post',
                    withCredentials: true,
                }).then(res => {
                    if (res.data === "success") {
                        localStorage.setItem('userInfo', JSON.stringify({
                            name: this.user,
                        }))
                        eB.$emit('user-login', 'hehe')
                        this.$notify({
                            title: '注册成功',
                            message: '3秒后自动为你重定向',
                            type: 'success'
                        });
                        setTimeout(() => {
                            this.$nextTick(() => {
                                let t = this.$route.query.redirect
                                if (t) {
                                    this.$router.push(t)
                                } else {
                                    this.$router.push('/')
                                }
                            })
                        }, 2000)
                    } else if (res.data === 'exist') {
                        this.$notify.error({
                            title: '注册失败',
                            message: '账号已存在!'
                        });
                    }
                }).catch(res => {
                    this.$notify.error({
                        title: '注册失败',
                        message: '服务器繁忙中...'
                    });
                })
                loading.close()
            },
        },
    }
</script>

<style lang='less'>

    .ad-panel {
        float: left;
        margin: 0 auto;
        width: 80%;
    }

    .register-container {
        align-items: center;
    }

    .login-panel {
        background-color: rgba(255, 255, 255, 80%);
        background-image: url('../assets/img/ad.jpg');
        background-repeat: no-repeat;
        padding: 1em;
        justify-content: center;
        flex: 1;
        width: auto;
        height: 400px;

        .el-row {
            margin-top: 0.5em;
            width: 15em;
        }
    }

    .info-panel {
        flex-direction: column;
        margin-top: 3em;
    }

    .login-button {
        text-align: center;
    }

</style>