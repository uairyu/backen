<template>
    <div class="artical-container">
        <div v-if="!status" style="height: 500px;line-height: 500px">
            <h2>文章不存在</h2>
        </div>
        <div v-else style="display: flex">
            <div class="flex2p5 mleft border-shadow">
                <div class="fullHW">
                    <div class="title-container">
                        <p class="intp">发布于 {{date}} /  浏览数: {{views}} </p>
                        <div class="art-tags">
                            <el-tag>标签一</el-tag>
                            <el-tag type="success">标签二</el-tag>
                            <el-tag type="info">标签三</el-tag>
                            <el-tag type="warning">标签四</el-tag>
                            <el-tag type="danger">标签五</el-tag>
                        </div>
                        <h2>{{title}}标题</h2>
                        <hr style=""/>
                        <div class="content-container">
                            <p>{{content}}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="flex mright border-shadow">
                <!--作者-->
                <div class="user-intro">
                    <div class="profile-photo">
                        <h1>头像</h1>
                    </div>
                    <p class="intp">作者: <span>{{author}}</span></p>
                </div>
            </div>
        </div>


    </div>
</template>

<script>
    import dayjs from 'dayjs'
    export default {
        name: "artical",
        data(){return{
            id: 0,
            author:'',
            title:'',
            content:'',
            date:'',
            views:0,
            discusses:'',
            status: true
        }},
        created() {
            this.id = this.$attrs.id
            if(this.id){
                this.$axios.get(this._G.baseURL + '/getShortArtical/' + this.id)
                .then(ret=>{
                    let d = ret.data
                    if(d===''){
                        this.status = false;
                    }
                    else{
                        this.author=d.author
                        this.title = d.title
                        this.content= d.content
                        this.views = d.views
                        this.discusses = d.views
                        this.date = dayjs(d.date).format('YYYY-MM-DD HH:mm:ss')
                        this.status = true
                    }
                }).catch(ret=>{
                    console.log(ret)
                    this.status = false
                })

            }
        }
    }

</script>

<style lang="less">
    .artical-container {
        justify-content: space-around;
        display: flex;
        flex-wrap: wrap;
        padding: 0 1em;
        margin-top: 2em;
        box-sizing: border-box;
        .mleft {
            flex-basis: 600px;

        }

        .mright {
            flex-basis: 150px;
        }

        .title-container {
            /*width: 100%;*/
            padding:0 1em;
        }
    }

    .art-tags {
        margin-bottom: 1em;
        & > * {
            margin-right: 1em;
        }
    }
    .mright{
        padding: 1em 1em;
    }
    .profile-photo {
        border: 1px solid black;
        width: 100px;
        height: 100px;
    }
    .intp{
        color: #aaa;
        font-size: 12px;
    }

</style>