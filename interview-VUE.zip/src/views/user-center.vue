<template>
    <div class="flex user-center-container">
        <div class="asider">
            <el-menu
                    class="el-menu-vertical-demo"
                    background-color="#545c64"
                    text-color="#fff"
                    active-text-color="#ffd04b"
                    default-active="2">
                <el-menu-item index="2" >
                    <i class="el-icon-menu"></i>
                    <span slot="title" @click="show_which='userCenterInfo'">个人中心</span>
                </el-menu-item>
                <el-menu-item index="3">
                    <i class="el-icon-setting"></i>
                    <span slot="title" @click="show_which=''">其它功能</span>
                </el-menu-item>
                <el-menu-item index="4">
                    <i class="el-icon-setting"></i>
                    <span slot="title" @click="show_which=''">其它功能</span>
                </el-menu-item>
                <el-menu-item index="5">
                    <i class="el-icon-setting"></i>
                    <span slot="title" @click="show_which=''">其它功能</span>
                </el-menu-item>
            </el-menu>
        </div>
        <div class="flex2 xq">
            <keep-alive>
                <component :is="show_which" ></component>
            </keep-alive>
        </div>
    </div>
</template>

<script>
    import userCenterInfo from './user-center-info'
    export default {
        name: "user-enter",
        components:{
            userCenterInfo
        },
        data(){return{
            show_which:'userCenterInfo'
        }}
    }
</script>

<style lang="less">

    .asider {
        flex: 0 0 10%;
        align-self: center;
    }

    .xq {

    }
</style>