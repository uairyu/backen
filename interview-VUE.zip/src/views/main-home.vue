<template>
    <div>
        <nav_banner></nav_banner>
        <div class="flex main-home-container">
            <hr style="border:1px dotted #ddd">
            <!--<img src="@/assets/img/ppt/1.png">-->
            <div class='flex'>
                <!--左-->
                <div class="flex">
                    <div class="row-left">
                        <ul class="border-shadow">
                            <li class="el-menu-item" style="border-left: 5px solid #428bca">文字文字文字文字文字</li>
                            <li>
                                <a class="el-menu-item border" style="width:33.3%; display: inline-block"><i
                                        class="el-icon-s-promotion"/>快讯</a>
                                <a class="el-menu-item border" style="width:33.3%; display: inline-block"><i
                                        class="el-icon-search"/>浏览</a>
                                <a class="el-menu-item border" style="width:33.3%; display: inline-block"><i
                                        class="el-icon-s-comment"/>评论</a>
                            </li>
                            <li class="border el-menu-item">新闻标题有很多字</li>
                            <li class="el-menu-item border">新闻标题有很多字</li>
                            <li class="el-menu-item border">新闻标题有很多字</li>
                        </ul>
                    </div>
                </div>
                <!--中-->
                <div class="flex2p5 middle-container">
                    <div class="row-middle fullW">
                        <div class="block ">
                            <!--ppt-->
                            <el-carousel>
                                <el-carousel-item v-for="(item,index) in ppt" :key="index">
                                    <img :src='item'>
                                    <!--<img :src="item">-->
                                </el-carousel-item>
                            </el-carousel>
                        </div>

                        <!--中间新闻-->
                        <div class='ntop'>
                            <div class="head" style="line-height: 3em;height: 3em;">
                                <span style=" display: inline-block">栏目标题</span>
                                <a href="#" style="float: right;font-size: 10px">查看更多</a>
                            </div>
                            <ul style="margin-top: 1em">
                                <router-link :to="'/artical/' + i.id" v-for="i in short_artical.slice((cur_page-1)*page_size,(cur_page)*page_size)" :key="i.id">
                                    <short_news>
                                        <template v-slot:title>{{i.title}}</template>
                                        <template v-slot:time>{{i.date}}</template>
                                        <template v-slot:username>{{i.author}}</template>
                                        <template v-slot:views>{{i.views}}</template>
                                        <template v-slot:discusses>{{i.discusses}}</template>
                                    </short_news>
                                </router-link>
                            </ul>
                            <!--分页-->
                            <div class="page-divider">
                                <el-pagination
                                        background
                                        layout="prev, pager, next"
                                        :current-page="cur_page"
                                        :page-size="page_size"
                                        :total="short_artical.length"
                                @current-change="(k)=> cur_page=k">
                                </el-pagination>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex1">
                    <div class="row-right">
                        <div style="padding-right: 1em">
                            <ul class=" fullW">
                                <li class="flex " style="height: 3em; line-height: 3em; border-left: 5px solid #428bca">
                                    <span style="flex:1 ;padding-left: 0.5em">图片世界</span>
                                    <span style="padding-right: 0.5em">
              <el-link type="primary"><i class="el-icon-more"/></el-link>
              </span>
                                </li>
                                <ul>
                                    <hr style="border:1px dotted #ddd">
                                    <li>
                                        <news_pic_info :img_src="this.getImg('/ppt/1.png')">
                                            <template v-slot:date>08-23</template>
                                            <template v-slot:views>2333</template>
                                            <template v-slot:discusses>23333</template>
                                        </news_pic_info>
                                    </li>
                                    <hr style="border:1px dotted #ddd">
                                    <li>
                                        <news_pic_info :img_src="this.getImg('ppt/2.png')">
                                            <template v-slot:date>08-23</template>
                                            <template v-slot:views>2333</template>
                                            <template v-slot:discusses>23333</template>
                                        </news_pic_info>
                                    </li>
                                </ul>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div></div>
        </div>
    </div>
</template>

<script>
    import news_pic_info from "@/components/news_pic_info";
    import short_news from "@/components/short_news";
    import nav_banner from "@/components/nav_banner";

    export default {
        name: "main-home",
        components: {
            news_pic_info, short_news, nav_banner
        },
        computed: {
            ppt() {
                let b = ['ppt/1.png', '/ppt/2.png', 'ppt/3.png']
                return this.getImg(b)
            }
        },
        data() {
            return {
              max_page: 10,
                page_size: 2,
                query_page_size:10,
                cur_page: 1,
                short_artical: []
            }
        },
        methods: {
            getShortArtical(queryPage) {
                this.$axios({
                    url: this._G.baseURL + '/getShortArtical',
                    method: 'get',
                    params: {
                        curPage: queryPage,
                        pageSize: this.query_page_size
                    }
                }).then(ret => {
                    this.short_artical = this.short_artical.concat(ret.data)
                }).catch(ret => {
                    console.log(ret)
                })
            }
        },
        created() {
            this.getShortArtical(1);
        }
    }
</script>

<style lang="less">
    @import "../assets/css/common.css";
    //ppt begin
    .demonstration {
        display: block;
        color: #8492a6;
        font-size: 14px;
        margin-bottom: 20px
    }

    li {
        .el-menu-item {
            padding: 0 5px;
            text-align: center;
        }
    }

    .el-carousel__item h3 {
        color: #475669;
        font-size: 14px;
        opacity: 0.75;
        line-height: 150px;
        margin: 0;
    }

    .el-carousel__item:nth-child(2n) {
        background-color: #99a9bf;
    }

    .el-carousel__item:nth-child(2n+1) {
        background-color: #d3dce6;
    }

    //ppt end
    .middle-container {
        flex-direction: column;
        padding-left: 1em;
        padding-right: 1em;
    }


    .ntop {
        margin-top: 2em;
        border-top: 1px solid #eaeaea;
        border-bottom: 1px solid #eaeaea;
        min-height: 200px;
        .head {
            border-bottom: 1px solid #eaeaea;
        }
    }

    .main-home-container {
        margin-top: 2em;
    }

    .row-left {
        display: block;
        margin: 0 auto;
        width: 80%;
    }

    .row-middle {
        display: block;
        margin: 0 auto;
    }

    .row-right {
        display: block;
        margin: 0 auto;
    }

    .page-divider {
        width: 100%;
        text-align: center;
        /*vertical-align: center;*/
        > div {
            margin: 0 auto;

        }
    }
</style>