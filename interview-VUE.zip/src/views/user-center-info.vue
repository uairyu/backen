<template>
    <div class="fullW" style="margin-top: 3em">
        <div class='center-info row-middle' style="width:60%">
            <h3>用户名修改</h3>
            <el-form label-width="80px">
                <el-form-item label="新用户名">
                    <el-input v-model="user"></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button @click="update_user(user)">修改</el-button>
                </el-form-item>
            </el-form>
            <hr/>
            <h3>密码修改</h3>
            <el-form :model="form_pas" label-width="5em">
                <el-form-item label="旧密码">
                    <el-input v-model="form_pas.oldpas" placeholder="请输入旧密码" show-password/>
                </el-form-item>
                <el-form-item label="新密码">
                    <el-input v-model="form_pas.newpas1" placeholder="请输入新密码" show-password/>
                </el-form-item>
                <el-form-item label="">
                    <el-input v-model="form_pas.newpas2" placeholder="再次输入新密码" show-password/>
                </el-form-item>
                <el-form-item>
                    <el-button>提交</el-button>
                </el-form-item>
            </el-form>
        </div>
    </div>
</template>

<script>
    import {eB} from "../assets/js/eventBus";

    export default {
        name: "user-center-info",
        data() {
            return {
                user: '',
                userObject: {},
                oldpas: '',
                newpas1: '',
                newpas2: '',
                form_pas: {}
            }
        },
        methods: {
            update_user(new_user_name) {
                this.$axios({
                    url: this._G.baseURL + '/update_user_name',
                    method: 'post',
                    data: {
                        user: new_user_name
                    },
                    withCredentials: true
                }).then(ret=>{
                    if(ret.data==='success'){
                        let st = window.localStorage
                        if (st){
                            let k = st.getItem('userInfo')
                            let b = JSON.parse(k)
                            b.name=new_user_name
                            st.setItem('userInfo',JSON.stringify(b))
                            eB.$emit('user-login')
                            this.$notify({
                                title: '修改成功',
                                message: '用户名修改成功',
                                type: 'success'
                            });
                        }
                    }
                    console.log(ret)
                }).catch(ret=>{
                    this.$notify({
                        title: '修改失败',
                        message: '用户名修改失败',
                        type: 'error'
                    });
                    console.log(ret)
                })
            }
        },
        created() {
            let b = localStorage.getItem('userInfo')
            if (b) {
                this.userObject = JSON.parse(b);
                if (this.userObject) {
                    this.user = this.userObject.name
                }
            }
        }
    }
</script>

<style lang="less">
    .center-info {
        /*justify-content: center;*/
        align-items: center;
        flex-direction: column;

        h3 {
            height: 2em;

        }

        .el-input {
            width: 20em;
        }

    }
</style>