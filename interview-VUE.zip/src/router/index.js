import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import register from "../views/register";
import userCenter from '@/views/user-center'
import artical from "../views/artical";

Vue.use(VueRouter)

const routes = [

    {
        path: '/',
        name: 'Home',
        component: Home
    },
    {path: '/register', component: register},
    {path: '/artical/:id', component: artical, props: true},
    {
        path: '/user', component: userCenter, meta: {
            requireLogin: true,
        }, children: [
            {path: '*'}
        ]
    },
]

const router = new VueRouter({
    routes,
})
router.beforeEach((to, from, next) => {

    if (to.matched.some((i) => i.meta.requireLogin)) {
        let b = localStorage.getItem('userInfo')
        if (b) {
            next()
        } else {
            next({
                path: '/register',
                query: {redirect: to.fullPath}
            });
        }
    } else {
        next();
    }

})
export default router
