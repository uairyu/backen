import Vue from 'vue'
export const eB = new Vue()
