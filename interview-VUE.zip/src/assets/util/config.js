
const production = process.env.NODE_ENV
const _GConfig = require("@/config/_GConfig")
export default {

    baseURL: production === 'production' ? _GConfig.virtualPath : 'http://localhost'  ,
}