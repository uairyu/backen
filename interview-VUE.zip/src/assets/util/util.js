exports.install = function(Vue){
	Vue.prototype.getAssets = function(rel_path){
		return require('@/assets/' + rel_path)
	}
	Vue.prototype.getImg = function(rel_path){
		if(rel_path !== null && rel_path !== undefined && rel_path.length > 0){
			if(rel_path instanceof Array){
				rel_path.forEach((s, index,a)=>{
					if (s.charAt(0) === '/'){
						s=s.substring(1)
					}
					a[index] = require('@/assets/img/' + s)
				})
				return rel_path
			}else{
				if (rel_path.charAt(0) === '/'){
					rel_path = rel_path.substring(1)
				}
				return require('@/assets/img/' + rel_path)
			}
		}
	}
}
