<template>
  <div class="short-news-cot">
    <li class="el-menu-item mid-news">
      <h2 class="clear">
        <i class="el-icon-apple"/><slot name="title"></slot>
      </h2>
      <div class="flex">
        <span><i class="el-icon-time"/><slot name="time"></slot></span>
        <span><i class="el-icon-user"/><slot name="username"></slot></span>
        <span><i class="el-icon-search"/><slot name="views"></slot></span>
        <span><i class="el-icon-s-comment"/><slot name="discusses"></slot></span>
      </div>
    </li>
  </div>
</template>

<script>
export default {
  name: "short_news"
}
</script>

<style lang="less" scoped>
  .clear{
    font-weight: normal;
    font-size: 1em;
    @h : 2em;
    height: @h;
    line-height: @h;
  }
  .news_title{
    display: block;
    @h:1.5em;
    height: @h;
    line-height: @h;
  }
  .mid-news {
    margin-top: 0.1em;
    @h: 4em;
    height: @h !important;
    line-height: 1em !important;
    border-top: 1px solid #eaeaea;
    flex-direction: column;
    .flex >span{
      display: flex;
      flex:1 ;
      vertical-align: middle;
      @h: 1em;
      height: @h;
      line-height: @h;
      font-size: 0.8em;
      padding-top: 2px;
      i{
        height: @h;
        line-height: 14px;
      }
    }
  }
</style>