<template>
  <div class="flex nav-banner-container">
    <div class=" logo">
      <h1 style="margin: 0; font-size: 40px;color: white">LOGO</h1>
    </div>
    <div class="flex">
      <div class="entry">
        <ul>
          <li>
            <span class="category">热门</span>
            <a href="#">热门内容</a>
            <a href="#">热门内容</a>
            <a href="#">热门内容</a>
          </li>
          <li>
            <span class="category">热门</span>
            <a href="#">热门内容</a>
            <a href="#">热门内容</a>
            <a href="#">热门内容</a>
          </li>
          <li>
            <span class="category">热门</span>
            <a href="#">热门内容</a>
            <a href="#">热门内容</a>
            <a href="#">热门内容</a>
          </li>
          <li>
            <span class="category">热门</span>
            <a href="#">热门内容</a>
            <a href="#">热门内容</a>
            <a href="#">热门内容</a>
          </li>
          <li>
            <span class="category">热门</span>
            <a href="#">热门内容</a>
            <a href="#">热门内容</a>
            <a href="#">热门内容</a>
          </li>
        </ul>
      </div>
    </div>

  </div>
</template>

<script>
export default {
  name: "nav_banner"
}
</script>

<style lang="less">
.nav-banner-container {
  background-color: #214e89;
  @h: 7em;
  height: @h;
  .logo{
    width: 300px;
    text-align: center;
    line-height: @h;
  }
}
.entry {
  width: 100%;
  color: white;
  font-size: 12px;
  ul{
    float:left;
    width:100%;
    height: 100%;
  }
  li{
    float: left;
    height: 3em;
    line-height: 3em;
    width: 50%;
    color: white;
    .category{
      display: inline-block;
      background: url("../assets/img/navLiC.png") 30px 3px no-repeat;
      padding-right: 1em;
      margin-right: 1em;
      font-weight: 900;
    }
    a{
      display: inline-block;
      width: 20%;
      color: white;
    }
  }
}
</style>