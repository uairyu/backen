<template>
    <div class="flex header">
        <div class='flex topNav' style="justify-content: space-between; padding-right: 1em; padding-left: 1em">
            <router-link to="/">Home</router-link>
            <div v-if="JSON.stringify(user)!=='{}'">
                <span>你好, <span class="username"><router-link to="/user"> {{user.name}}</router-link></span></span>
                <a href="#" @click.prevent="logout" style=":hover{text-decoration: underline}">&nbsp; 退出登陆</a>
            </div>
            <div v-else>
                <router-link to="/register" class="">注册/登陆</router-link>
            </div>
        </div>
    </div>
</template>
<script>
    import {eB} from "../assets/js/eventBus";

    export default {
        name: "home-header",
        methods: {
            e_user_login() {
                this.updateLogin()
            },
            logout() {
                let st = window.localStorage
                st.removeItem('userInfo')
                this.user = {}
                this.$axios({
                    url:this._G.baseURL + '/logout',
                    method: 'get',
                    withCredentials: true
                }).then()
                location.reload();
            },
            updateLogin() {
                //  若已经登陆,则在localStorage取用户信息
                let st = window.localStorage
                if (!st) {
                    alert('浏览器不支持localStorage')
                    return
                }
                let userInfo = st.getItem('userInfo')
                if (userInfo) {
                    userInfo = JSON.parse(userInfo)
                    if (userInfo && JSON.stringify(userInfo) !== '{}') {
                        this.isLogin = true
                        this.user = userInfo
                    } else {
                        st.removeItem('userInfo')
                    }
                }
            }
        },
        data() {
            return {
                isLogin: false,
                user: {}
            }
        },
        beforeDestroy() {
            eB.$off('user-login')
        },
        created() {
            eB.$on('user-login', () => this.e_user_login())

        },
        mounted() {
            this.updateLogin()
        }
    }
</script>

<style>
    .topNav {
        height: 2em;
        line-height: 2em;
    }

    .header {
        height: 2em;
        background-color: rgb(239, 239, 239);
    }

    .username {
        color: crimson;
        text-decoration: underline;
    }
</style>