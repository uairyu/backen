<template>
  <div >
      <div class="flex" style="width: 15em; height: 9em">
        <a class="news_img" href="#">
          <img :src="img_src"/>
          <span class="sp">文字简介</span>
        </a>
      </div>
      <div class = 'flex param' style="font-size: 0.7em;">
        <!--日期-->
        <span style="flex:1"><slot name="date"></slot></span>
        <!--  查看数-->
        <span style="flex: 2"><i class="el-icon-search"/><slot name="views"></slot></span>
        <!--  讨论数-->
        <span style="flex: 1"> <i class="el-icon-s-comment"/><slot name="discusses"></slot></span>
      </div>
  </div>
</template>
<script>
export default {
  props: ['img_src'],
  name: "news_pic_info"
}
console.log()
</script>

<style>

.param{
  height: 2em;
  line-height: 2em;
  vertical-align: center;
}

.news_img {
  position: relative;
  width: 100%;
}

.news_img img{
  height: 100%;
  width: 100%;
}
.sp {
  position: absolute;
  bottom: 0;
  width: 100%;
  height: 1.5em;
  line-height: 1.5em;
  left: 0;
  color: white;
  font-size: 0.9em;
  text-align: center;
  background-color: #333;
  opacity: 80%;
}
</style>