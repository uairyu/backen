<template>
  <div class="flex footer-container">
    <div class="flex">
      <div class="copyRight row-middle">
        <p>CopyRight © 2021 hyuairyu@foxmail.com All Right Reserved.</p>
      </div>
    </div>

  </div>
</template>

<script>
export default {
  name: "home-footer"
}
</script>

<style >
.footer-container {
  flex-direction: row;
  justify-content: space-between;
}

.copyRight {

}
</style>