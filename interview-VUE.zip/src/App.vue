<template>
  <div id="app">
    <nav_header></nav_header>
    <router-view></router-view>
    <hr style="border:1px dotted #ddd">
    <nav_footer></nav_footer>
  </div>
</template>
<script>
  import nav_header from '@/components/home-header'
  import nav_footer from '@/components/home-footer'
  import common_css from '@/assets/css/common.css'
  export default {
    name: "App",
    components:{
      nav_header, nav_footer, common_css,
    }
  }
</script>
<style lang="less">

</style>
